<div class="footer bg-white py-4 d-flex flex-lg-column " id="kt_footer">
	<!--begin::Container-->
	Highgate Census and Marketing Report built by <a class="footer_link" target="_new" href="http://www.pcseattle.net">Technology Portal</a>
</div>
<?php /**PATH /storage/ssd5/289/14284289/public_html/resources/views/layouts/footer.blade.php ENDPATH**/ ?>