<?php $__env->startSection('content'); ?>
    <!--begin: Wizard-->
    <div class="wizard wizard-3" id="kt_wizard_v3" data-wizard-state="first" data-wizard-clickable="true">

        <!--begin: Wizard Body-->
        <div class="row justify-content-center py-10 px-8 py-lg-12 px-lg-10">
            <?php echo $__env->yieldContent('contents'); ?>
        </div>
        <!--end: Wizard Body-->
    </div>
    <!--end: Wizard-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/ssd2/433/14364433/public_html/resources/views/layouts/container.blade.php ENDPATH**/ ?>