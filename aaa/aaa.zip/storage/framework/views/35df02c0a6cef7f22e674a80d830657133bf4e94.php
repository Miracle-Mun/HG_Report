<div class="footer bg-white py-4 d-flex flex-lg-column " id="kt_footer">
	<!--begin::Container-->
	<div class=" container  d-flex flex-column flex-md-row align-items-center justify-content-between">

		<!--begin::Nav-->
		<div class="footerData" style="color: white;">
			Highgate Census and Marketing Report built by <a class="footer_link" target="_new" href="http://www.pcseattle.net">Technology Portal</a>
		</div>
		<!--end::Nav-->
	</div>
	<!--end::Container-->
</div>
<?php /**PATH C:\xampp\htdocs\Laravel_project\new_project\resources\views/layouts/footer.blade.php ENDPATH**/ ?>