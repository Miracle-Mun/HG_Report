<?php $__env->startSection('contents'); ?>

    <?php
        use App\model\reports;
        use App\model\periods;
        use App\model\cencaps;
        use App\model\buildings;
        use App\model\moveouts;
        use App\model\inquiries;
        use App\model\Communities;

        $reports = new reports;
        $periods = new periods;
        $cencaps = new cencaps;
        $buildings = new buildings;
        $moveouts = new moveouts;
        $inquiries = new inquiries;
        $Communities = new Communities;

        $info = explode(',', Session::get('info'));
        $reportsData = json_decode($reports->where(['community_id' => $info[0], ['period_id', '>=', $info[1]],  ['period_id', '<=', $info[2]] ])->get());
        $mainPeriod = json_decode($periods->where([['id', '>=', $info[1]],  ['id', '<=', $info[2]] ])->get());
        $inquiriesData2 = [];
        foreach ($reportsData as $key => $value) {
            $row = json_decode($inquiries->where(['report_id' => $value->id])->groupBy('report_id')->get()); 
            array_push($inquiriesData2, $row);                         
        }

        $finalArr = [];
        foreach($reportsData as $knowNumber => $item) {

            $data = json_decode($cencaps->where(['report_id' => $item->id])->get());

            $idArr = [];
            for( $i = count($data) - 1 ; $i >= 0 ; $i--) {
                if(gettype(array_search($data[$i]->building_id, $idArr)) == 'boolean') {
                    array_push($finalArr, $data[$i]);
                }
                array_push($idArr, $data[$i]->building_id);
            }

        }
        $idArr = [];
        $oneArr = [];
        for( $i = 0 ; $i < count($finalArr) ; $i++) {
            $myId = $finalArr[$i]->building_id;
            if(gettype(array_search($myId, $idArr)) == 'boolean') {
                $oneArr[$myId] = [];
                array_push($idArr, $myId);
                array_push($oneArr[$myId], $finalArr[$i]);
            }
            else {
                array_push($oneArr[$myId], $finalArr[$i]);
            }
        }
        $sumArrFinal = [];

        $moveoutDates = [];
        foreach ($mainPeriod as $key => $value) {
            array_push($moveoutDates, $value->caption);
            if($key == count($mainPeriod) - 1) {
                array_push($moveoutDates, 'Total');
                array_push($moveoutDates, 'Average');
            }
        }
        $moveoutDescriptions = [];
        foreach ($reportsData as $key => $value) {
            $moveoutsData = json_decode($moveouts->where(['report_id' => $value->id])->get());
            if(count($moveoutsData) > 0) {
                array_push($moveoutDescriptions, $moveoutsData[0]->description);
            }
        }
    ?>

    <div class="row summarycontainer">
        <table class="table table-borderless viewtable mycontroltable  table-sm table-hover">
            <tbody>
                <tr class="headbang">
                    <th style="font-size: 15px !important; font-weight:bold !important;" rowspan="<?php echo e(count($reportsData) + 3); ?>" class="MainTitletwo">Current<br>Census</th>
                    <th></th>
                    <?php $__currentLoopData = $mainPeriod; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th><?php echo e($item->caption); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <th style="font-size: 15px !important; font-weight:bold !important;">Average</th>
                </tr>
                <?php $AllArr = []; $mainSum1 = 0; $i_num1 = 0;?>
                <?php $__currentLoopData = $oneArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(json_decode($buildings->where( [ 'id' => $key ] )->get())[0]->name); ?></td>
                        <?php $sum = 0; $onArr = [];?>
                        <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $sum += $row->census; array_push($onArr, $row->census); ?>
                            <td><?php echo e($row->census); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php array_push($AllArr, $onArr); $mainSum1 += number_format($sum / count($item), 2, '.', "") ;?>
                        <td><?php echo e(number_format($sum / count($item), 2, '.', "")); ?></td>
                    </tr>
                    <?php $i_num1++; ?>
                    <?php if($i_num1 == count($oneArr)): ?>
                        <tr>
                            <th>Total</th>
                            <?php $__currentLoopData = $AllArr[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mainkey => $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $allSum = 0; ?>
                                <?php $__currentLoopData = $AllArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key_val => $Arr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $allSum += $AllArr[$key_val][$mainkey]; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php array_push($sumArrFinal, $allSum); ?>
                                <td><?php echo e($allSum); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td><?php echo e($mainSum1); ?></td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tbody>
                <?php $AllArr = []; $mainSum2 = 0; $i_num2 = 0;?>
                <?php $__currentLoopData = $oneArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <?php if($mainSum2 == 0): ?>
                            <th style="font-size: 15px !important; font-weight:bold !important;" rowspan="<?php echo e(count($reportsData) + 3); ?>" class="MainTitletwo">Total<br>Capacity</th>
                        <?php endif; ?>
                        <td><?php echo e(json_decode($buildings->where( [ 'id' => $key ] )->get())[0]->name); ?></td>
                        <?php $sum = 0; $onArr = [];?>
                        <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $sum += $row->capacity; array_push($onArr, $row->capacity); ?>
                            <td><?php echo e($row->capacity); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php array_push($AllArr, $onArr); $mainSum2 += number_format($sum / count($item), 2, '.', "") ;?>
                        <td><?php echo e(number_format($sum / count($item), 2, '.', "")); ?></td>
                    </tr>
                    <?php $i_num2++; ?>
                    <?php if($i_num2 == count($oneArr)): ?>
                        <tr>
                            <th>Total</th>
                            <?php $__currentLoopData = $AllArr[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mainkey => $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $allSum = 0; ?>
                                <?php $__currentLoopData = $AllArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key_val => $Arr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $allSum += $AllArr[$key_val][$mainkey]; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php $sumArrFinal[$mainkey] = number_format( 100 * $sumArrFinal[$mainkey] / $allSum, 2, '.', "") ; ?>
                                <td><?php echo e($allSum); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td><?php echo e($mainSum2); ?></td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tbody>
                <?php $AllArr = []; $mainSum = 0; $i_num3 = 0;?>
                <?php $__currentLoopData = $oneArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <?php if($i_num3 == 0): ?>
                            <th style="font-size: 15px !important; font-weight:bold !important;" rowspan="<?php echo e(count($reportsData) + 3); ?>" class="MainTitletwo">Census<br> vs<br> Capacity</th>
                        <?php endif; ?>
                        <td><?php echo e(json_decode($buildings->where( [ 'id' => $key ] )->get())[0]->name); ?></td>
                        <?php $sum = 0; $onArr = [];?>
                        <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $sum += number_format($row->census * 100 / $row->capacity, 2, '.', ""); array_push($onArr, number_format($row->census * 100 / $row->capacity, 2, '.', "")); ?>
                            <td><?php echo e(number_format($row->census * 100 / $row->capacity, 2, '.', "")); ?> %</td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php array_push($AllArr, $onArr); $mainSum += number_format($sum / count($item), 2, '.', "") ;?>
                        <td><?php echo e(number_format($sum / count($item), 2, '.', "")); ?> %</td>
                    </tr>
                    <?php $i_num3++; ?>
                    <?php if($i_num3 == count($oneArr)): ?>
                        <tr>
                            <th>Total</th>
                            <?php $__currentLoopData = $sumArrFinal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mainkey => $one): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td><?php echo e($one); ?> %</td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td><?php echo e(number_format( 100 * $mainSum1 / $mainSum2, 2, '.', "")); ?> %</td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php if(count($inquiriesData2) > 0): ?>
            <table class="table table-borderless viewtable mycontroltable  table-sm table-hover">
                <tbody>
                    <tr class="titledate">
                        <th class="MainTitletwo" rowspan="<?php echo e(count($inquiriesData2) + 10); ?>">Type <br> of <br> Inquiries</th>
                        <td></td>
                        <?php $__currentLoopData = $moveoutDates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td><?php echo e($item); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                    <?php $__currentLoopData = $ownmainData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->description); ?></td>
                            <?php $sum = 0; ?>
                            <?php $__currentLoopData = $periodsData2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $da): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($da['id'] == $item->period_id): ?>
                                    <?php $sum += $item->sum; ?>
                                    <td><?php echo e($item->sum); ?></td>
                                <?php else: ?>
                                    <td>0</td>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td><?php echo e($sum); ?></td>
                            <td><?php echo e(number_format($sum/count($periodsData2), 2, '.', '')); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th>Total</th>
                        <?php $__currentLoopData = $periodsData2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $da): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $sum = 0; ?>
                            <?php $__currentLoopData = $WholeSum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($da['id'] == $item->period_id): ?>
                                    <?php $sum += $item->sum; ?>
                                    <td><?php echo e($item->sum); ?></td>
                                <?php else: ?>
                                    <td>0</td>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($sum); ?></td>
                        <td><?php echo e(number_format($sum/count($periodsData2), 2, '.', '')); ?></td>
                    </tr>
                </tbody>
            </table>
        <?php endif; ?>
        <?php if(count($moveoutDescriptions) > 0): ?>
            <table class="table table-borderless viewtable mycontroltable  table-sm table-hover">
                <tbody>
                    <tr class="titledate">
                        <th class="MainTitletwo" rowspan="<?php echo e(count($moveoutDescriptions) + 3); ?>">Move-Out <br> Reasons</th>
                        <td></td>
                        <?php $__currentLoopData = $moveoutDates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td><?php echo e($item); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                    <?php $__currentLoopData = $moveoutDescriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item); ?></td>
                            <?php  $myval = 0; ?>
                            <?php $__currentLoopData = $reportsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $moveoutsData = json_decode($moveouts->where(['report_id' => $value->id])->get());?>
                                <?php if(count($moveoutsData) > 0 && $moveoutsData[0]->description == $item): ?>
                                    <?php $myval += $moveoutsData[0]->number; ?>
                                    <td><?php echo e($moveoutsData[0]->number); ?></td>
                                <?php else: ?>
                                    <td></td>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td><?php echo e($myval); ?></td>
                            <td><?php echo e(number_format( $myval / count($moveoutDates), 2,'.', '' )); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
        <table class="table table-borderless viewtable mycontroltable  table-sm table-hover">
            <tbody>
                <tr class="titledate">
                    <th class="MainTitletwo" rowspan="<?php echo e(count($moveoutDescriptions) + 10); ?>">Statistics</th>
                    <td></td>
                    <?php $__currentLoopData = $moveoutDates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($item); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
                <tr>
                    <td>Inqueries</td>
                    <?php $moveSum = 0; ?>
                    <?php $__currentLoopData = $reportsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $moveSum += $item->unqualified; ?>
                        <td><?php echo e($item->unqualified); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($moveSum); ?></td>
                    <td><?php echo e(number_format( $moveSum / count($reportsData), 2, '.', '')); ?></td>
                </tr>
                <tr>
                    <td>Unqualified</td>
                    <?php $moveSum = 0; ?>
                    <?php $__currentLoopData = $reportsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $moveSum += $item->unqualified; ?>
                        <td><?php echo e($item->unqualified); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($moveSum); ?></td>
                    <td><?php echo e(number_format( $moveSum / count($reportsData), 2, '.', '')); ?></td>
                </tr>
                <tr>
                    <td>Tours</td>
                    <?php $moveSum = 0; ?>
                    <?php $__currentLoopData = $reportsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $moveSum += $item->tours; ?>
                        <td><?php echo e($item->tours); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($moveSum); ?></td>
                    <td><?php echo e(number_format( $moveSum / count($reportsData), 2, '.', '')); ?></td>
                </tr>
                <tr>
                    <td>Deposits</td>
                    <?php $moveSum = 0; ?>
                    <?php $__currentLoopData = $reportsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $moveSum += $item->deposits; ?>
                        <td><?php echo e($item->deposits); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($moveSum); ?></td>
                    <td><?php echo e(number_format( $moveSum / count($reportsData), 2, '.', '')); ?></td>
                </tr>
                <tr>
                    <td>Inquiries to Tour</td>
                    <?php $moveSum = 0; ?>
                    <?php $__currentLoopData = $reportsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->tours == 0): ?>
                            <td>0 %</td>
                        <?php else: ?>
                            <?php $moveSum += $item->deposits / $item->tours; ?>
                            <td><?php echo e($item->deposits / $item->tours); ?> %</td>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($moveSum); ?></td>
                    <td><?php echo e(number_format( $moveSum / count($reportsData), 2, '.', '')); ?></td>
                </tr>
                <tr>
                    <td>Tours to Deposits</td>
                    <?php $moveSum = 0; ?>
                    <?php $__currentLoopData = $reportsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->tours == 0): ?>
                            <td>0 %</td>
                        <?php else: ?>
                            <?php $moveSum += $item->deposits / $item->tours; ?>
                            <td><?php echo e($item->deposits / $item->tours); ?> %</td>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($moveSum); ?></td>
                    <td><?php echo e(number_format( $moveSum / count($reportsData), 2, '.', '')); ?></td>
                </tr>
            </tbody>
        </table>

        <table class="table table-borderless viewtable  table-sm table-hover">
            <tbody>
                <tr class="titledate">
                    <th class="MainTitletwo" rowspan="<?php echo e(count($moveoutDescriptions) + 10); ?>">Move In/Out</th>
                    <td></td>
                    <?php $__currentLoopData = $moveoutDates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($item); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
                <tr>
                    <td>WTD Move-Ins</td>
                    <?php $moveSum = 0; ?>
                    <?php $__currentLoopData = $reportsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $moveSum += $item->wtd_movein; ?>
                        <td><?php echo e($item->wtd_movein); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($moveSum); ?></td>
                    <td><?php echo e(number_format( $moveSum / count($reportsData), 2, '.', '')); ?></td>
                </tr>
                <tr>
                    <td>WTD Move-Outs</td>
                    <?php $moveSum = 0; ?>
                    <?php $__currentLoopData = $reportsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $moveSum += $item->wtd_moveout; ?>
                        <td><?php echo e($item->wtd_moveout); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($moveSum); ?></td>
                    <td><?php echo e(number_format( $moveSum / count($reportsData), 2, '.', '')); ?></td>
                </tr>
                <tr>
                    <td>WTD Net Residents</td>
                    <?php $moveSum = 0; ?>
                    <?php $__currentLoopData = $reportsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $moveSum += $item->wtd_movein - $item->wtd_moveout; ?>
                        <td><?php echo e($item->wtd_movein - $item->wtd_moveout); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($moveSum); ?></td>
                    <td><?php echo e(number_format( $moveSum / count($reportsData), 2, '.', '')); ?></td>
                </tr>
                <tr>
                    <td>YTD Move-Ins</td>
                    <?php $moveSum = 0; ?>
                    <?php $__currentLoopData = $reportsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $moveSum += $item->ytd_movein; ?>
                        <td><?php echo e($item->ytd_movein); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($moveSum); ?></td>
                    <td><?php echo e(number_format( $moveSum / count($reportsData), 2, '.', '')); ?></td>
                </tr>
                <tr>
                    <td>YTD Move-Outs</td>
                    <?php $moveSum = 0; ?>
                    <?php $__currentLoopData = $reportsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $moveSum += $item->ytd_moveout; ?>
                        <td><?php echo e($item->ytd_moveout); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($moveSum); ?></td>
                    <td><?php echo e(number_format( $moveSum / count($reportsData), 2, '.', '')); ?></td>
                </tr>
                <tr>
                    <td>YTD Net Residents</td>
                    <?php $moveSum = 0; ?>
                    <?php $__currentLoopData = $reportsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $moveSum += $item->ytd_movein - $item->ytd_moveout; ?>
                        <td><?php echo e($item->ytd_movein - $item->ytd_moveout); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($moveSum); ?></td>
                    <td><?php echo e(number_format( $moveSum / count($reportsData), 2, '.', '')); ?></td>
                </tr>
            </tbody>
        </table>
        
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.container', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/ViewReportsSecond.blade.php ENDPATH**/ ?>