<?php $__env->startSection('contents'); ?>
<?php
    use App\model\Communities;
    use App\model\periods;
    $viewitems = ( new Communities )->get();
    $perioditems = ( new periods )->orderBy('id','desc')->limit(48)->get();
?>

<div class="col-xl-12 TitleHeaderBar">
    <h3 class="landingtitle">View Reports for Any Community</h3>
</div>

<div class="col-xl-12 ContentBar">
    <div class="col-lg-12 col-xl-12">
        <form action="/reportSummary" method="post">
            <?php echo csrf_field(); ?>
            <div class="row align-items-center">
                <div class="col-md-7 my-2 my-md-0">
                    <div class="d-flex align-items-center">
                        <label class="mr-3 mb-0 d-none d-md-block">View</label>
                        <div class="dropdown bootstrap-select form-control">
                            <div class="dropdown bootstrap-select form-control">
                                <div class="row">
                                    <div class="col-lg-4 col-md-9 col-sm-12">
                                        <div class="dropdown bootstrap-select form-control dropdownC">
                                            <input name="community_id" class="dn">
                                            <select class="form-control selectpicker" data-live-search="true" tabindex="null">
                                                <?php $__currentLoopData = $viewitems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option data-tokens="mustard" cId="<?php echo e($item->id); ?>">
                                                        <?php echo e($item->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 my-2 my-md-0">
                    <div class="d-flex align-items-center">
                        <label class="mr-3 mb-0 d-none d-md-block">
                            Period:
                        </label>
                        <input type="button" class="span2 btn-rounded checkdate_1" value="Click here for date" onchange="getVal1(this)" id="dp1">
                        <input name="period_id" class="dn">
                    </div>
                </div>

                <div class="col-md-2 my-2 my-md-0">
                    <div class="input-icon">
                        <input class="dn submitInput" type="button">
                        <button class="ViewReportsOne goBtn btn-rounded" type="button" style="background: #80808f;">
                            <span class="iconify" data-icon="logos:go" data-inline="false"></span>
                        </button>
                    </div>
                </div>
                
            </div>
        </form>
    </div>
</div>

<div class="col-xl-12 ContentBar">
    <div class="col-lg-12 col-xl-12">
        <form action="/reportSummarySecond" method="post">
            <?php echo csrf_field(); ?>
            <div class="row align-items-center">
                
                <div class="col-md-3 my-2 my-md-0">
                    <div class="d-flex align-items-center">
                        <label class="mr-3 mb-0 d-none d-md-block">View</label>
                        <div class="dropdown bootstrap-select form-control">
                            <div class="dropdown bootstrap-select form-control">
                                <div class="row">
                                    <div class="col-lg-4 col-md-9 col-sm-12">
                                        <div class="dropdown bootstrap-select form-control dropdownC">
                                            <input name="community_id" class="dn">
                                            <select class="form-control selectpicker" data-live-search="true" tabindex="null">
                                                <?php $__currentLoopData = $viewitems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option data-tokens="mustard" cId="<?php echo e($item->id); ?>">
                                                        <?php echo e($item->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-4 my-2 my-md-0">
                    <div class="d-flex align-items-center">
                        <label class="mr-3 mb-0 d-none d-md-block">
                            Trend Report from
                        </label>
                        <input type="button" class="span2 btn-rounded checkdate_2" value="Click here for date" onchange="getVal2(this)" id="dp2">
                        <input name="period_id_from" class="dn dp2Value">
                    </div>
                </div>

                <div class="col-md-3 my-2 my-md-0">
                    <div class="d-flex align-items-center">
                        <label class="mr-3 mb-0 d-none d-md-block">
                            to &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        </label>
                        <input type="button" class="span2 btn-rounded checkdate_2" value="Click here for date" onchange="getVal3(this)" id="dp3">
                        <input name="period_id_to" class="dn dp3Value">
                    </div>
                </div>

                <div class="col-md-2 my-2 my-md-0">
                    <div class="input-icon">
                        <input class="dn submitInput1" type="button">
                        <button class="goBtn btn-rounded" type="button"  style="background: #80808f;">
                            <span class="iconify" data-icon="logos:go" data-inline="false"></span>
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<div class="col-xl-12 TitleHeaderBar">
    <h3 class="landingtitle">Company Reports</h3>
</div>
<div class="col-xl-12 ContentBar">
    <div class="col-lg-12 col-xl-12">
        <form action="creports" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row align-items-center">
                <div class="col-md-10 my-2 my-md-0">
                    <div class="d-flex align-items-center">
                        <label class="mr-3 mb-0 d-none d-md-block vewCompany">
                            View Company Summary for Period:&nbsp;
                        </label>
                        <input type="button" class="span2 btn-rounded checkdate_1" value="Click here for date" onchange="getVal4(this)" id="dp4">
                        <input name="period_id" class="dn">
                    </div>
                </div>
                <div class="col-md-2 my-2 my-md-0">
                    <div class="input-icon">
                        <input class="dn submitInput2" type="button">
                        <button class="goBtn btn-rounded" type="button" style="background: #80808f;">
                            <span class="iconify" data-icon="logos:go" data-inline="false"></span>
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<div class="col-xl-12 ContentBar">
    <div class="col-lg-12 col-xl-12">
        <form action="creportsSec" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row align-items-center">
                <div class="col-md-7 my-2 my-md-0">
                    <div class="d-flex align-items-center">
                        <label class="mr-3 mb-0 d-none d-md-block vewCompany">
                            View Company Trend Report from &nbsp;&nbsp;&nbsp;&nbsp;
                        </label>
                        <input type="button" class="span2 btn-rounded checkdate_1" value="Click here for date" onchange="getVal5(this)" id="dp5">
                        <input name="period_id_from" class="dn dp5Value">
                    </div>
                </div>
                <div class="col-md-3 my-2 my-md-0">
                    <div class="d-flex align-items-center">
                        <label class="mr-3 mb-0 d-none d-md-block vewCompany">
                            to &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        </label>
                        <input type="button" class="span2 btn-rounded checkdate_1" value="Click here for date" onchange="getVal6(this)" id="dp6">
                        <input name="period_id_to" class="dn dp6Value">
                    </div>
                </div>
                <div class="col-md-2 my-2 my-md-0">
                    <div class="input-icon">
                        <input class="dn submitInput3" type="button">
                        <button class="goBtn btn-rounded" type="button" style="background: #80808f;">
                            <span class="iconify" data-icon="logos:go" data-inline="false"></span>
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<div class="col-xl-12 TitleHeaderBar">
    <h3 class="landingtitle">Edit Previous Reports</h3>
</div>
<div class="col-xl-12 ContentBar">
    <div class="col-lg-12 col-xl-12">
        <form action="editaction" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row align-items-center">
                <div class="col-md-6 my-2 my-md-0">
                    <div class="d-flex align-items-center">
                        <label class="mr-3 mb-0 d-none d-md-block">Edit</label>
                        <div class="dropdown bootstrap-select form-control">
                            <div class="dropdown bootstrap-select form-control">
                                <div class="row">
                                    <div class="col-lg-4 col-md-9 col-sm-12">
                                        <div class="dropdown bootstrap-select form-control dropdownC">
                                            <input name="community_id" class="dn">
                                            <select class="form-control selectpicker" data-live-search="true" tabindex="null">
                                                <?php $__currentLoopData = $viewitems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option data-tokens="mustard" cId="<?php echo e($item->id); ?>">
                                                        <?php echo e($item->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 my-2 my-md-0">
                    <div class="d-flex align-items-center">
                        <label class="mr-3 mb-0 d-none d-md-block vewCompany">
                            Report for Period: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        </label>
                        <input type="button" class="span2 btn-rounded checkdate_1" value="Click here for date" onchange="getVal7(this)" id="dp7">
                        <input name="period_id" class="dn dp7Value">
                    </div>
                </div>
                <div class="col-md-2 my-2 my-md-0">
                    <div class="input-icon">
                        <input class="dn submitInput4" type="button">
                        <button class="goBtn btn-rounded" type="button" style="background: #80808f;">
                            <span class="iconify" data-icon="logos:go" data-inline="false"></span>
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<div class="col-xl-12 TitleHeaderBar">
    <h3 class="landingtitle">User Administration</h3>
</div>
<div class="col-xl-12 ContentBar">
    <div class="col-lg-12 col-xl-12">
        <div class="row align-items-center">
            <div class="col-md-12 my-2 my-md-0">
                <button class="btn-rounded">
                    <a href="usermanage" style="color: white !important;">                        
                        Click Here to Enter User <span class="iconify" data-icon="whh:useralt" data-inline="false"></span> Administration.
                    </a>
                </button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.container', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\resources\views/layouts/mainpageContainer.blade.php ENDPATH**/ ?>