

<?php $__env->startSection('contents'); ?>

    <?php
        use App\model\reports;
        use App\model\periods;
        use App\model\cencaps;
        use App\model\buildings;
        use App\model\moveouts;
        use App\model\inquiries;
        use App\model\Communities;

        $reports = new reports;
        $periods = new periods;
        $cencaps = new cencaps;
        $buildings = new buildings;
        $moveouts = new moveouts;
        $inquiries = new inquiries;
        $Communities = new Communities;
        $info = explode(',', Session::get('info'));
        $reportsData = json_decode($reports->where(['community_id' => $info[0], 'period_id' => $info[1]])->get());
        if(count($reportsData) != 0) {
            $cencapsData = json_decode($cencaps->where(['report_id' => $reportsData[0]->id])->get());
            $moveoutsData = json_decode($moveouts->where(['report_id' => $reportsData[0]->id])->get());
            $inquiriesData = json_decode($inquiries->where(['report_id' => $reportsData[0]->id])->get());
        }
        $viewitems = ( new Communities )->get();
        // dd($cencapsData);
    ?>

    <script> 
        var communities = <?php echo $viewitems; ?>;
    </script>

    <div class="row summarycontainer me">
        <table class="table table-borderless viewtable table-hover">
            <thead>
                <tr>
                    <form method="POST" action="reportSummary">
                        <?php echo csrf_field(); ?>
                        <h3 class="px-2 w-100">
                            Report Summary for
                            <?php $__currentLoopData = $viewitems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($key == 0): ?>
                                    <input name="community_id" value=<?php echo e($item->id); ?> class="dn com">
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <select class="form-control selectpicker w-20 viewreportcommon" data-live-search="true" tabindex="null">
                                <?php $__currentLoopData = $viewitems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($info[0] == $item->id): ?>
                                        <option data-tokens="mustard" selected="selected">
                                            <?php echo e($item->name); ?>

                                        </option>
                                    <?php else: ?>
                                        <option data-tokens="mustard">
                                            <?php echo e($item->name); ?>

                                        </option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            from
                            <input class="dn" name="period_id" value="<?php echo e(json_decode($periods->where(['id' => $info[1]])->get())[0]->id); ?>">
                            <input class="dn" type="submit">
                            <input type="button" class="span2 btn-rounded period_id" date="<?php echo e(json_decode($periods->where(['id' => $info[1]])->get())[0]->id); ?>" value="<?php echo e(json_decode($periods->where(['id' => $info[1]])->get())[0]->caption); ?>" onchange="refresh(this)" id="dp1">
                        </h3>
                    </form>
                </tr>
            </thead>
            <tbody>
                <?php if(isset($cencapsData)): ?>
                    <tr>
                        <th rowspan="<?php echo e(count($cencapsData) + 2); ?>" class="MainTitle">Census</th>
                        <th></th>
                        <th>Census</th>
                        <th>Capacity</th>
                        <th>%</th>
                    </tr>

                    <?php $iNum = 0; $cencusSum = 0; $capacitySum = 0;?>
                    <?php $__currentLoopData = $cencapsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $cencusSum += $item->census;
                            $capacitySum += $item->capacity;
                        ?>
                        <tr>
                            <td>
                                <?php echo e(json_decode($buildings->where(['id' => $item->building_id])->get())[0]->name); ?>

                            </td>
                            <td><?php echo e($item->census); ?></td>
                            <td><?php echo e($item->capacity); ?></td>
                            <td><?php echo e(number_format(100 * $item->census/$item->capacity, 2, '.', "") . '%'); ?></td>
                        </tr>
                        <?php $iNum++; ?>
                        <?php if( $iNum == count($cencapsData)): ?>
                            <tr>
                                <th>Total</th>
                                <th><?php echo e($cencusSum); ?></th>
                                <th><?php echo e($capacitySum); ?></th>
                                <th><?php echo e(number_format(100 * $cencusSum/$capacitySum, 2, '.', "") . '%'); ?></th>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>There is no data.</tr>
                <?php endif; ?>
            </tbody>
        </table>
        <?php if(isset($inquiriesData)): ?>
            <table class="table table-borderless viewtable table-hover">
                <tbody>
                    <tr>
                        <th rowspan="<?php echo e(count($inquiriesData) + 2); ?>" class="MainTitle">Inquiries</th>
                        <th>Type</th>
                        <th>Count</th>
                    </tr>
                    <?php $iNum = 0; $numSum = 0;?>
                    <?php $__currentLoopData = $inquiriesData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->description); ?></td>
                            <td><?php echo e($item->number); ?></td>
                        </tr>
                        <?php $iNum++; $numSum += $item->number; ?>
                        <?php if( $iNum == count($inquiriesData)): ?>
                            <tr>
                                <th>Total</th>
                                <th><?php echo e($numSum); ?></th>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>

        <?php if(isset($moveoutsData)): ?>
            <table class="table table-borderless viewtable table-hover">
                <tbody>
                    <tr>
                        <th rowspan="<?php echo e(count($moveoutsData) + 2); ?>" class="MainTitle">Move-Outs</th>
                        <th>Type</th>
                        <th>Count</th>
                    </tr>
                    <?php $iNum = 0; $numSum = 0;?>
                    <?php $__currentLoopData = $moveoutsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->description); ?></td>
                            <td><?php echo e($item->number); ?></td>
                        </tr>
                        <?php $iNum++; $numSum += $item->number; ?>
                        <?php if( $iNum == count($moveoutsData)): ?>
                            <tr>
                                <th>Total</th>
                                <th><?php echo e($numSum); ?></th>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
        <?php if(count($reportsData)): ?>
            <table class="table table-borderless viewtable table-hover" style="border: none !important;">
                <tbody>
                    <tr>
                        <th rowspan="6" class="MainTitle">Statistics</th>
                        <td>Unqualified</td>
                        <td><?php echo e($reportsData[0]->unqualified); ?></td>
                    </tr>
                    <tr>
                        <td>Tours</td>
                        <td><?php echo e($reportsData[0]->tours); ?></td>
                    </tr>
                    <tr>
                        <td>Deposits</td>
                        <td><?php echo e($reportsData[0]->deposits); ?></td>
                    </tr>
                    <tr>
                        <td>Inquiries to Tours</td>
                        <?php if($reportsData[0]->deposits == 0): ?>
                            <td>0 %</td>
                        <?php else: ?>
                            <td><?php echo e(number_format( $reportsData[0]->tours / $reportsData[0]->deposits, 2, '.', '')); ?> %</td>
                        <?php endif; ?>
                    </tr>
                    <tr>
                        <td>Tours to Deposits</td>
                        <?php if($reportsData[0]->tours == 0): ?>
                            <td>0 %</td>
                        <?php else: ?>
                            <td><?php echo e($reportsData[0]->deposits / $reportsData[0]->tours); ?> %</td>
                        <?php endif; ?>
                    </tr>
                </tbody>
            </table>
            <table class="table table-borderless viewtable table-hover" style="border-top: 2px solid;">
                <tbody>
                    <tr>
                        <th rowspan="6" class="MainTitle">Move In/Out</th>
                        <td>WTD Move-Ins</td>
                        <td><?php echo e($reportsData[0]->wtd_movein); ?></td>
                    </tr>
                    <tr>
                        <td>WTD Move-Outs</td>
                        <td><?php echo e($reportsData[0]->wtd_moveout); ?></td>
                    </tr>
                    <tr>
                        <td>WTD Net Residents</td>
                        <td><?php echo e($reportsData[0]->wtd_movein - $reportsData[0]->wtd_moveout); ?></td>
                    </tr>
                    <tr>
                        <td>YTD Move-Ins</td>
                        <td><?php echo e($reportsData[0]->ytd_movein); ?></td>
                    </tr>
                    <tr>
                        <td>YTD Move-Outs</td>
                        <td><?php echo e($reportsData[0]->ytd_moveout); ?></td>
                    </tr>
                    <tr>
                        <td>YTD Net Residents</td>
                        <td><?php echo e($reportsData[0]->ytd_movein - $reportsData[0]->ytd_moveout); ?></td>
                    </tr>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.container', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/ssd2/433/14364433/public_html/resources/views/ViewReports.blade.php ENDPATH**/ ?>