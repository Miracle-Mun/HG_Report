<?php $__env->startSection('contents'); ?>
<?php
    use App\model\Communities;
    use App\model\periods;
    $viewitems = ( new Communities )->get();
    $perioditems = ( new periods )->orderBy('id','desc')->limit(48)->get();
?>

<div class="col-xl-12 TitleHeaderBar">
    <h3 class="landingtitle">View Reports for Any Community</h3>
</div>

<div class="col-xl-12 ContentBar">
    <div class="col-lg-12 col-xl-12">
        <form action="/reportSummary" method="post">
            <?php echo csrf_field(); ?>
            <div class="row align-items-center">

                <div class="col-md-5 my-2 my-md-0">
                    <div class="d-flex align-items-center">
                        <label class="mr-3 mb-0 d-none d-md-block">View</label>
                        <div class="dropdown bootstrap-select form-control">
                            <button aria-expanded="false" aria-haspopup="listbox" aria-owns="bs-select-2" class="btn dropdown-toggle btn-light bs-placeholder" data-id="kt_datatable_search_type" data-toggle="dropdown" role="combobox" tabindex="-1" title="All" type="button">
                            <div class="filter-option">
                                <div class="filter-option-inner">
                                    <input class="ViewReportsOneCommunity" name="community_id" style="display: none;" value="<?php echo e($viewitems[0]->id); ?>">
                                    <div class="filter-option-inner-inner ViewReportsOneCommunity">
                                        <?php echo e($viewitems[0]->name); ?>

                                    </div>
                                </div>
                            </div></button>
                            <div class="dropdown-menu" style="max-height: 426.75px; overflow: hidden; min-height: 130px;">
                                <div aria-activedescendant="bs-select-2-0" class="inner show" id="bs-select-2" role="listbox" style="max-height: 414.75px; overflow-y: auto; min-height: 118px;" tabindex="-1">
                                    <ul class="dropdown-menu inner show" role="presentation" style="margin-top: 0px; margin-bottom: 0px;">
                                        <?php $__currentLoopData = $viewitems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($item->name != 'Administration'): ?>
                                                <li class="selected active" type="ViewReportsOne" cId="<?php echo e($item->id); ?>">
                                                    <a aria-posinset="1" aria-selected="true" aria-setsize="4" class="dropdown-item active selected" id="bs-select-2-0" role="option" tabindex="0">
                                                        <span class="text"><?php echo e($item->name); ?></span>
                                                    </a>
                                                </li>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-5 my-2 my-md-0">
                    <div class="d-flex align-items-center">
                        <label class="mr-3 mb-0 d-none d-md-block">Period:</label>
                        <div class="dropdown bootstrap-select form-control">
                            <button aria-expanded="false" aria-haspopup="listbox" aria-owns="bs-select-2" class="btn dropdown-toggle btn-light bs-placeholder" data-id="kt_datatable_search_type" data-toggle="dropdown" role="combobox" tabindex="-1" title="All" type="button">
                            <div class="filter-option">
                                <div class="filter-option-inner">
                                    <input class="ViewReportsOnePeriod" name="period_id" style="display: none;" value="<?php echo e($perioditems[0]->id); ?>">
                                    <div class="filter-option-inner-inner ViewReportsOnePeriod">
                                        <?php echo e($perioditems[0]->caption); ?>

                                    </div>
                                </div>
                            </div></button>
                            <div class="dropdown-menu" style="max-height: 426.75px; overflow: hidden; min-height: 130px;">
                                <div aria-activedescendant="bs-select-2-0" class="inner show" id="bs-select-2" role="listbox" style="max-height: 414.75px; overflow-y: auto; min-height: 118px;" tabindex="-1">
                                    <ul class="dropdown-menu inner show" role="presentation" style="margin-top: 0px; margin-bottom: 0px;">
                                        
                                            <?php $__currentLoopData = $perioditems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?></li>
                                                <li class="selected active" pId="<?php echo e($item->id); ?>" type="ViewReportsOne">
                                                    <a aria-posinset="1" aria-selected="true" aria-setsize="4" class="dropdown-item active selected" id="bs-select-2-0" role="option" tabindex="0">
                                                        <span class="text"><?php echo e($item->caption); ?></span>
                                                    </a>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-2 my-2 my-md-0">
                    <div class="input-icon">
                        <button class="ViewReportsOne goBtn btn-rounded" type="submit">Go</button>
                    </div>
                </div>
                
            </div>
        </form>
    </div>
</div>

<div class="col-xl-12 ContentBar">
    <div class="col-lg-12 col-xl-12">
        <form action="/reportSummarySecond" method="post">
            <?php echo csrf_field(); ?>
            <div class="row align-items-center">
                
                <div class="col-md-2 my-2 my-md-0">
                    <div class="d-flex align-items-center">
                        <label class="mr-3 mb-0 d-none d-md-block">View</label>
                        <div class="dropdown bootstrap-select form-control">
                            <button aria-expanded="false" aria-haspopup="listbox" aria-owns="bs-select-2" class="btn dropdown-toggle btn-light bs-placeholder" data-id="kt_datatable_search_type" data-toggle="dropdown" role="combobox" tabindex="-1" title="All" type="button">
                                <div class="filter-option">
                                    <div class="filter-option-inner">
                                        <input class="ViewReportsOneCommunity" name="community_id" style="display: none;" value="<?php echo e($viewitems[0]->id); ?>">
                                        <div class="filter-option-inner-inner">
                                            <?php echo e($viewitems[0]->name); ?>

                                        </div>
                                    </div>
                                </div>
                            </button>
                            <div class="dropdown-menu" style="max-height: 426.75px; overflow: hidden; min-height: 130px;">
                                <div aria-activedescendant="bs-select-2-0" class="inner show" id="bs-select-2" role="listbox" style="max-height: 414.75px; overflow-y: auto; min-height: 118px;" tabindex="-1">
                                    <ul class="dropdown-menu inner show" role="presentation" style="margin-top: 0px; margin-bottom: 0px;">
                                        <?php $__currentLoopData = $viewitems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($item->name != 'Administration'): ?>
                                                <li class="selected active" type="ViewReportsSec" pId="<?php echo e($item->id); ?>">
                                                    <a aria-posinset="1" aria-selected="true" aria-setsize="4" class="dropdown-item active selected" id="bs-select-2-0" role="option" tabindex="0">
                                                        <span class="text"><?php echo e($item->name); ?></span>
                                                    </a>
                                                </li>
                                            <?php endif; ?> 
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-5 my-2 my-md-0">
                    <div class="d-flex align-items-center">
                        <label class="mr-3 mb-0 d-none d-md-block">Trend Report from</label>
                        <div class="dropdown bootstrap-select form-control mydropdown">
                            <button aria-expanded="false" aria-haspopup="listbox" aria-owns="bs-select-2" class="btn dropdown-toggle btn-light bs-placeholder" data-id="kt_datatable_search_type" data-toggle="dropdown" role="combobox" tabindex="-1" title="All" type="button">
                            <div class="filter-option">
                                <div class="filter-option-inner">
                                    <input class="ViewReportsOnePeriodOne" name="period_id_from" style="display: none;" value="<?php echo e($perioditems[0]->id); ?>">
                                    <div class="filter-option-inner-inner">
                                        <?php echo e($perioditems[0]->caption); ?>

                                    </div>
                                </div>
                            </div></button>
                            <div class="dropdown-menu" style="max-height: 426.75px; overflow: hidden; min-height: 130px;">
                                <div aria-activedescendant="bs-select-2-0" class="inner show" id="bs-select-2" role="listbox" style="max-height: 414.75px; overflow-y: auto; min-height: 118px;" tabindex="-1">
                                    <ul class="dropdown-menu inner show" role="presentation" style="margin-top: 0px; margin-bottom: 0px;">
                                        <?php $__currentLoopData = $perioditems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="selected active" type="ViewReportsSec" cId="<?php echo e($item->id); ?>">
                                                <a aria-posinset="1" aria-selected="true" aria-setsize="4" class="dropdown-item active selected" id="bs-select-2-0" role="option" tabindex="0">
                                                    <span class="text"><?php echo e($item->caption); ?></span>
                                                </a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-3 my-2 my-md-0">
                    <div class="d-flex align-items-center">
                        <label class="mr-3 mb-0 d-none d-md-block">to</label>
                        <div class="dropdown bootstrap-select form-control">
                            <button aria-expanded="false" aria-haspopup="listbox" aria-owns="bs-select-2" class="btn dropdown-toggle btn-light bs-placeholder" data-id="kt_datatable_search_type" data-toggle="dropdown" role="combobox" tabindex="-1" title="All" type="button">
                            <div class="filter-option">
                                <div class="filter-option-inner">
                                    <input class="ViewReportsOnePeriodSec" name="period_id_to" style="display: none;" value="<?php echo e($perioditems[0]->id); ?>">
                                    <div class="filter-option-inner-inner">
                                        <?php echo e($perioditems[0]->caption); ?>

                                    </div>
                                </div>
                            </div></button>
                            <div class="dropdown-menu" style="max-height: 426.75px; overflow: hidden; min-height: 130px;">
                                <div aria-activedescendant="bs-select-2-0" class="inner show" id="bs-select-2" role="listbox" style="max-height: 414.75px; overflow-y: auto; min-height: 118px;" tabindex="-1">
                                    <ul class="dropdown-menu inner show" role="presentation" style="margin-top: 0px; margin-bottom: 0px;">
                                        <?php $__currentLoopData = $perioditems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="selected active" type="ViewReportsSec" cId="<?php echo e($item->id); ?>">
                                                <a aria-posinset="1" aria-selected="true" aria-setsize="4" class="dropdown-item active selected" id="bs-select-2-0" role="option" tabindex="0">
                                                    <span class="text"><?php echo e($item->caption); ?></span>
                                                </a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-2 my-2 my-md-0">
                    <div class="input-icon">
                        <button class="goBtn btn-rounded" type="submit">Go</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<div class="col-xl-12 TitleHeaderBar">
    <h3 class="landingtitle">Company Reports</h3>
</div>
<div class="col-xl-12 ContentBar">
    <div class="col-lg-12 col-xl-12">
        <form action="creports" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row align-items-center">
                <div class="col-md-10 my-2 my-md-0">
                    <div class="d-flex align-items-center vewCompany">
                        <label class="mr-3 mb-0 d-none d-md-block">View Company Summary for Period:</label>
                        <div class="dropdown bootstrap-select form-control viewCompanySummaryForPeriod">
                            <button aria-expanded="false" aria-haspopup="listbox" aria-owns="bs-select-2" class="btn dropdown-toggle btn-light bs-placeholder" data-id="kt_datatable_search_type" data-toggle="dropdown" role="combobox" tabindex="-1" title="All" type="button">
                            <div class="filter-option">
                                <div class="filter-option-inner">
                                    <div class="filter-option-inner-inner">
                                        <?php echo e($perioditems[0]->caption); ?>

                                    </div>
                                    <input name="period_id" value="<?php echo e($perioditems[0]->id); ?>" class="dn">
                                </div>
                            </div></button>
                            <div class="dropdown-menu" style="max-height: 426.75px; overflow: hidden; min-height: 130px;">
                                <div aria-activedescendant="bs-select-2-0" class="inner show" id="bs-select-2" role="listbox" style="max-height: 414.75px; overflow-y: auto; min-height: 118px;" tabindex="-1">
                                    <ul class="dropdown-menu inner show" role="presentation" style="margin-top: 0px; margin-bottom: 0px;">
                                        <?php $__currentLoopData = $perioditems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="selected active" pId="<?php echo e($item->id); ?>">
                                                <a aria-posinset="1" aria-selected="true" aria-setsize="4" class="dropdown-item active selected" id="bs-select-2-0" role="option" tabindex="0">
                                                    <span class="text"><?php echo e($item->caption); ?></span>
                                                </a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-2 my-2 my-md-0">
                    <div class="input-icon">
                        <button class="goBtn btn-rounded" type="submit">Go</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<div class="col-xl-12 ContentBar">
    <div class="col-lg-12 col-xl-12">
        <form action="creportsSec" method="POST">
            <?php echo csrf_field(); ?>
            <div class="row align-items-center">
                <div class="col-md-8 my-2 my-md-0">
                    <div class="d-flex align-items-center vewCompany">
                        <label class="mr-3 mb-0 d-none d-md-block">View Company Trend Report from</label>
                        <div class="dropdown bootstrap-select form-control viewCompanySummaryForPeriod">
                            <button aria-expanded="false" aria-haspopup="listbox" aria-owns="bs-select-2" class="btn dropdown-toggle btn-light bs-placeholder" data-id="kt_datatable_search_type" data-toggle="dropdown" role="combobox" tabindex="-1" title="All" type="button">
                            <div class="filter-option">
                                <div class="filter-option-inner">
                                    <input class="ViewReportsOnePeriodSec" name="period_id_from" style="display: none;" value="<?php echo e($perioditems[0]->id); ?>">
                                    <div class="filter-option-inner-inner">
                                        <?php echo e($perioditems[0]->caption); ?>

                                    </div>
                                </div>
                            </div></button>
                            <div class="dropdown-menu" style="max-height: 426.75px; overflow: hidden; min-height: 130px;">
                                <div aria-activedescendant="bs-select-2-0" class="inner show" id="bs-select-2" role="listbox" style="max-height: 414.75px; overflow-y: auto; min-height: 118px;" tabindex="-1">
                                    <ul class="dropdown-menu inner show" role="presentation" style="margin-top: 0px; margin-bottom: 0px;">
                                        <?php $__currentLoopData = $perioditems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="selected active" pFrom="<?php echo e($item->id); ?>">
                                                <a aria-posinset="1" aria-selected="true" aria-setsize="4" class="dropdown-item active selected" id="bs-select-2-0" role="option" tabindex="0">
                                                    <span class="text"><?php echo e($item->caption); ?></span>
                                                </a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-2 my-2 my-md-0">
                    <div class="d-flex align-items-center vewCompany">
                        <label class="mr-3 mb-0 d-none d-md-block">to</label>
                        <div class="dropdown bootstrap-select form-control viewCompanySummaryForPeriodtwo">
                            <button aria-expanded="false" aria-haspopup="listbox" aria-owns="bs-select-2" class="btn dropdown-toggle btn-light bs-placeholder" data-id="kt_datatable_search_type" data-toggle="dropdown" role="combobox" tabindex="-1" title="All" type="button">
                            <div class="filter-option">
                                <div class="filter-option-inner">
                                    <input class="ViewReportsOnePeriodSec" name="period_id_to" style="display: none;" value="<?php echo e($perioditems[0]->id); ?>">
                                    <div class="filter-option-inner-inner">
                                        <?php echo e($perioditems[0]->caption); ?>

                                    </div>
                                </div>
                            </div></button>
                            <div class="dropdown-menu" style="max-height: 426.75px; overflow: hidden; min-height: 130px;">
                                <div aria-activedescendant="bs-select-2-0" class="inner show" id="bs-select-2" role="listbox" style="max-height: 414.75px; overflow-y: auto; min-height: 118px;" tabindex="-1">
                                    <ul class="dropdown-menu inner show" role="presentation" style="margin-top: 0px; margin-bottom: 0px;">
                                        <?php $__currentLoopData = $perioditems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="selected active" pTo="<?php echo e($item->id); ?>">
                                                <a aria-posinset="1" aria-selected="true" aria-setsize="4" class="dropdown-item active selected" id="bs-select-2-0" role="option" tabindex="0">
                                                    <span class="text"><?php echo e($item->caption); ?></span>
                                                </a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-2 my-2 my-md-0">
                    <div class="input-icon">
                        <button class="goBtn btn-rounded" type="submit">Go</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<div class="col-xl-12 TitleHeaderBar">
    <h3 class="landingtitle">Edit Previous Reports</h3>
</div>
<div class="col-xl-12 ContentBar">
    <div class="col-lg-12 col-xl-12">
        <div class="row align-items-center">
            <div class="col-md-4 my-2 my-md-0">
                <div class="d-flex align-items-center">
                    <label class="mr-3 mb-0 d-none d-md-block">Edit</label>
                    <div class="dropdown bootstrap-select form-control">
                        <button aria-expanded="false" aria-haspopup="listbox" aria-owns="bs-select-2" class="btn dropdown-toggle btn-light bs-placeholder" data-id="kt_datatable_search_type" data-toggle="dropdown" role="combobox" tabindex="-1" title="All" type="button">
                        <div class="filter-option">
                            <div class="filter-option-inner">
                                <div class="filter-option-inner-inner">
                                    <?php echo e($viewitems[0]->name); ?>

                                </div>
                            </div>
                        </div></button>
                        <div class="dropdown-menu" style="max-height: 426.75px; overflow: hidden; min-height: 130px;">
                            <div aria-activedescendant="bs-select-2-0" class="inner show" id="bs-select-2" role="listbox" style="max-height: 414.75px; overflow-y: auto; min-height: 118px;" tabindex="-1">
                                <ul class="dropdown-menu inner show" role="presentation" style="margin-top: 0px; margin-bottom: 0px;">
                                    <?php $__currentLoopData = $viewitems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                        <?php if($item->name != 'Administration'): ?>
                                            <li class="selected active" vId="<?php echo e($item->id); ?>">
                                                <a aria-posinset="1" aria-selected="true" aria-setsize="4" class="dropdown-item active selected" id="bs-select-2-0" role="option" tabindex="0">
                                                    <span class="text"><?php echo e($item->name); ?></span>
                                                </a>
                                            </li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 my-2 my-md-0">
                <div class="d-flex align-items-center">
                    <label class="mr-3 mb-0 d-none d-md-block">Report for Period:</label>
                    <div class="dropdown bootstrap-select form-control myreportperiod">
                        <button aria-expanded="false" aria-haspopup="listbox" aria-owns="bs-select-2" class="btn dropdown-toggle btn-light bs-placeholder" data-id="kt_datatable_search_type" data-toggle="dropdown" role="combobox" tabindex="-1" title="All" type="button">
                        <div class="filter-option">
                            <div class="filter-option-inner">
                                <div class="filter-option-inner-inner">
                                    <?php echo e($perioditems[0]->caption); ?>

                                </div>
                            </div>
                        </div></button>
                        <div class="dropdown-menu" style="max-height: 426.75px; overflow: hidden; min-height: 130px;">
                            <div aria-activedescendant="bs-select-2-0" class="inner show" id="bs-select-2" role="listbox" style="max-height: 414.75px; overflow-y: auto; min-height: 118px;" tabindex="-1">
                                <ul class="dropdown-menu inner show" role="presentation" style="margin-top: 0px; margin-bottom: 0px;">
                                    <?php $__currentLoopData = $perioditems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li class="selected active">
                                            <a aria-posinset="1" aria-selected="true" aria-setsize="4" class="dropdown-item active selected" id="bs-select-2-0" role="option" tabindex="0">
                                                <span class="text"><?php echo e($item->caption); ?></span>
                                            </a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-2 my-2 my-md-0">
                <div class="input-icon">
                    <button class="goBtn btn-rounded" type="button">Go</button>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="col-xl-12 TitleHeaderBar">
    <h3 class="landingtitle">User Administration</h3>
</div>
<div class="col-xl-12 ContentBar">
    <div class="col-lg-12 col-xl-12">
        <div class="row align-items-center">
            <div class="col-md-12 my-2 my-md-0">
                <a href="usermanage">Click Here to Enter User Administration.</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.container', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/ssd5/289/14284289/public_html/resources/views/layouts/mainpageContainer.blade.php ENDPATH**/ ?>