<div id="kt_header" class="header  header-fixed ">
    <div class="  d-flex align-items-stretch justify-content-between">
        <div class="d-flex align-items-stretch">
            <div class="header-logo">
                <a href="/"> <img alt="Logo" style="max-height: 80px !important; margin-left: 10%;" src="./logo.png" class="logo-default max-h-40px"> </a>
            </div>
            <div class="header-menu-wrapper header-menu-wrapper-left" id="kt_header_menu_wrapper">
                <div id="kt_header_menu" class="header-menu header-menu-left header-menu-mobile  header-menu-layout-default ">
                    <ul class="menu-nav ">
                        <?php
                            try {
                                $Sessionuserinfo = Session::get('session');
                                $RealName = $RealCom = '';
                                if($Sessionuserinfo) {
                                    $infoarr = explode(",", $Sessionuserinfo);
                                    $myInfo = DB::table('logins')->where(['username' => $infoarr[0], 'encrypted' => $infoarr[1]])->get('user_id');
                                    $userId = json_decode($myInfo)[0]->user_id;
                                    $RealName = json_decode(DB::table('users')->where('id', $userId)->get())[0]->name;
                                    $RealCom = json_decode(DB::table('communities')->where('id', json_decode(DB::table('users')->where('id', $userId)->get())[0]->community_id)->get())[0]->name;
                                }
                            } catch (Exception $e) {
                                Session::forget('session');
                                Session::flash('sessiondestroy','true');
                            }
                        ?>
                        <?php if(Session::get('sessiondestroy') == 'true'): ?>
                            <form style="display: none;" method="GET" action="/signout"><input id="signoutBtn"/></form>
                            <script> $('#signoutBtn').click(); </script>
                        <?php else: ?>
                            <li class="menu-item  menu-item-submenu menu-item-rel" data-menu-toggle="click" aria-haspopup="true">
                                Hello &nbsp;&nbsp; <b><?php echo e($RealName); ?></b>&nbsp;&nbsp; from&nbsp; <b> <?php echo e($RealCom); ?> </b>
                            </li>
                        <?php endif; ?>
                        <li class="menu-item  menu-item-submenu menu-item-rel" data-menu-toggle="click" aria-haspopup="true">
                            <a href="/main" class="menu-link menu-toggle gotoPage">
                                <span class="menu-text">Home</span>
                                <i class="menu-arrow"></i>
                            </a>
                        </li>
                        <li class="menu-item  menu-item-submenu menu-item-rel" data-menu-toggle="click" aria-haspopup="true">
                            <a href="/signout" class="menu-link menu-toggle gotoPage">
                                <span class="menu-text">Signout</span>
                                <i class="menu-arrow"></i>
                            </a>
                        </li>
                        <form method="GET" action=""><input type="submit" value="submit" id="goTopageAction" style="display: none;"></form>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /storage/ssd5/289/14284289/public_html/laravel_task/resources/views/layouts/header.blade.php ENDPATH**/ ?>