<?php $__env->startSection('contents'); ?>

    <?php
        use App\model\reports;
        use App\model\periods;
        use App\model\cencaps;
        use App\model\buildings;
        use App\model\moveouts;
        use App\model\Communities;

        $reports = new reports;
        $periods = new periods;
        $cencaps = new cencaps;
        $buildings = new buildings;
        $buildingsData = $buildings->get();
        $moveouts = new moveouts;
        $Communities = new Communities;
        $pId = Session::get('period');
        $reportsData = json_decode($reports->where(['period_id' => $pId])->orderBy('community_id')->get());
    ?>

    <div class="row summarycontainer">
        <table class="table table-borderless viewtable mycontroltable table-sm">
            <?php $sumc = []; $sump = []; ?>
            <tbody>
                <tr>
                    <th style="font-size: 15px !important; font-weight:bold !important;" rowspan="<?php echo e(count($reportsData) + 3); ?>" class="MainTitletwo">Current<br>Census</th>
                    <th></th>
                    <?php $__currentLoopData = $reportsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th><?php echo e(json_decode($Communities->where(['id' => $item->community_id])->get())[0]->name); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <th>Total</th>
                </tr>
                <?php $wholeSum = [];  ?>
                <?php $__currentLoopData = $buildingsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->name); ?></td>
                        <?php $sum = 0; $oneSum = []; ?>
                        <?php $__currentLoopData = $reportsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $cencapsData = $cencaps->where(['report_id' => $row->id])->get(); $Checkflag = false; ?>
                            <?php $__currentLoopData = $cencapsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cencpD): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($cencpD->building_id == $item->id && count($oneSum) < 9): ?>
                                    <?php $Checkflag = true; $sum += $cencpD->census; array_push($oneSum, $cencpD->census); ?>
                                    <td><?php echo e($cencpD->census); ?></td>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($Checkflag == false && count($oneSum) < 9): ?>
                                <?php array_push($oneSum, 0); ?>
                                <td></td>
                            <?php else: ?>
                                <?php $Checkflag = false; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php array_push($wholeSum, $oneSum ); ?>
                        <td><?php echo e($sum); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th>Total</th>
                    <?php $sumas = 0; ?>
                    <?php $__currentLoopData = $wholeSum[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $suma = 0; ?>
                        <?php $__currentLoopData = $wholeSum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $suma += $wholeSum[$col][$row]; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $sumas += $suma; array_push($sumc, $suma); ?>
                        <th><?php echo e($suma); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php array_push($sumc, $sumas); ?>
                    <th><?php echo e($sumas); ?></th>
                </tr>
            </tbody>
            <tbody>
                <?php $wholeSum1 = []; $inum = 0; ?>
                <?php $__currentLoopData = $buildingsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <?php if($inum == 0): ?>
                            <th style="font-size: 15px !important; font-weight:bold !important;" rowspan="<?php echo e(count($reportsData) + 3); ?>" class="MainTitletwo">Total<br>Capacity</th>
                            <?php $inum++; ?>
                        <?php endif; ?>
                        <td><?php echo e($item->name); ?></td>
                        <?php $sum = 0; $oneSum = []; ?>
                        <?php $__currentLoopData = $reportsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $cencapsData = $cencaps->where(['report_id' => $row->id])->get(); $Checkflag = false; ?>
                            <?php $__currentLoopData = $cencapsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cencpD): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($cencpD->building_id == $item->id && count($oneSum) < 9): ?>
                                    <?php $Checkflag = true; $sum += $cencpD->capacity; array_push($oneSum, $cencpD->capacity); ?>
                                    <td><?php echo e($cencpD->capacity); ?></td>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($Checkflag == false && count($oneSum) < 9): ?>
                                <?php array_push($oneSum, 0); ?>
                                <td></td>
                            <?php else: ?>
                                <?php $Checkflag = false; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php array_push($wholeSum1, $oneSum ); ?>
                        <td><?php echo e($sum); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th>Total</th>
                    <?php $sumas = 0; ?>
                    <?php $__currentLoopData = $wholeSum1[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $suma = 0; ?>
                        <?php $__currentLoopData = $wholeSum1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $suma += $wholeSum1[$col][$row]; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $sumas += $suma; array_push($sump, $suma); ?>
                        <th><?php echo e($suma); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php array_push($sump, $sumas); ?>
                    <th><?php echo e($sumas); ?></th>
                </tr>
            </tbody>
            <tbody>
                <?php $inum = 0; ?>
                <?php $__currentLoopData = $buildingsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <?php if($inum == 0): ?>
                            <th style="font-size: 15px !important; font-weight:bold !important;" rowspan="<?php echo e(count($reportsData) + 3); ?>" class="MainTitletwo">Census<br>vs<br>Capacity</th>
                            <?php $inum++; ?>
                        <?php endif; ?>
                        <td><?php echo e($item->name); ?></td>
                        <?php $sum1 = 0; $sum2 = 0; $number = 0;?>
                        <?php $__currentLoopData = $reportsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $cencapsData = $cencaps->where(['report_id' => $row->id])->get(); $Checkflag = false; ?>
                            <?php $__currentLoopData = $cencapsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cencpD): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($cencpD->building_id == $item->id && $number < 9): ?>
                                    <?php $number++; ?>
                                    <?php $Checkflag = true; $sum1 += $cencpD->census;  $sum2 += $cencpD->capacity; ?>
                                    <td><?php echo e(number_format( 100 * $cencpD->census / $cencpD->capacity, 2, '.', '' )); ?> %</td>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($Checkflag == false && $number < 9): ?>
                                <?php $number++; ?>
                                <td></td>
                            <?php else: ?>
                                <?php $Checkflag = false; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e(number_format( 100 * $sum1 / $sum2 , 2, '.', '')); ?> %</td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th>Total</th>
                    <?php $__currentLoopData = $sumc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th><?php echo e(number_format( 100 * $item / $sump[$key], 2, '.', '')); ?> %</th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </tbody>
        </table>
        
        <table class="table table-borderless viewtable mycontroltable table-sm">
            <tbody>
                <tr>
                    <th style="font-size: 15px !important; font-weight:bold !important;" rowspan="<?php echo e(count($reportsData) + 3); ?>" class="MainTitletwo">Move-Out<br>Reasons</th>
                    <th></th>
                    <?php $__currentLoopData = $reportsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th><?php echo e(json_decode($Communities->where(['id' => $item->community_id])->get())[0]->name); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <th>Total</th>
                </tr>
                <?php $ttArr = []; ?>
                <?php $__currentLoopData = $reportsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $moveOutData = $moveouts->where(['report_id' => $item->id])->get(); ?>
                    <?php if(count($moveOutData) > 0): ?>
                        <?php $__currentLoopData = $moveOutData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(gettype(array_search($item->description, $ttArr)) == 'boolean'): ?>
                                <?php array_push($ttArr, $item->description); ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php $wholeSumArr = []; ?>
                <?php $__currentLoopData = $ttArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php echo e($item); ?>

                        </td>
                        <?php $sum = 0; $sum_1Arr = []; ?>
                        <?php $__currentLoopData = $reportsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $moveOutData = $moveouts->where(['report_id' => $row1->id])->get(); $igetNum = 0; ?>
                            <?php if(count($moveOutData) > 0): ?>
                                <?php $__currentLoopData = $moveOutData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if( $item == $row->description && count($sum_1Arr) < 9): ?>  
                                        <?php $igetNum++; array_push($sum_1Arr, $row->number); $sum += $row->number;?>
                                        <td><?php echo e($row->number); ?></td>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            <?php if($igetNum > 0): ?>
                                <?php $igetNum = 0; ?>
                            <?php else: ?>
                                <?php if(count($sum_1Arr) < 9): ?>
                                    <?php array_push($sum_1Arr, 0); ?>
                                    <td></td>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <th><?php echo e($sum); ?></th>
                        <?php array_push($sum_1Arr, $sum); array_push($wholeSumArr, $sum_1Arr); $sum_1Arr = []; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th>Total</th>
                    <?php $__currentLoopData = $wholeSumArr[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $sumPart = 0; ?>
                        <?php $__currentLoopData = $wholeSumArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $sumPart += $wholeSumArr[$col][$row]; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <th><?php echo e($sumPart); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </tbody>
        </table>

        <table class="table table-borderless viewtable mycontroltable table-sm">
            <tbody>
                <tr>
                    <th style="font-size: 15px !important; font-weight:bold !important;" rowspan="<?php echo e(count($reportsData) + 3); ?>" class="MainTitletwo">Statistics</th>
                    <th></th>
                    <?php $__currentLoopData = $reportsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th><?php echo e(json_decode($Communities->where(['id' => $item->community_id])->get())[0]->name); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <th>Total</th>
                </tr>
                <tr>
                    <td>Inqueries</td>
                    <?php $moveSum = 0; ?>
                    <?php $__currentLoopData = $reportsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $moveSum += $item->unqualified; ?>
                        <td><?php echo e($item->unqualified); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($moveSum); ?></td>
                </tr>
                <tr>
                    <td>Unqualified</td>
                    <?php $moveSum = 0; ?>
                    <?php $__currentLoopData = $reportsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $moveSum += $item->unqualified; ?>
                        <td><?php echo e($item->unqualified); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($moveSum); ?></td>
                </tr>
                <tr>
                    <td>Tours</td>
                    <?php $moveSum = 0; ?>
                    <?php $__currentLoopData = $reportsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $moveSum += $item->tours; ?>
                        <td><?php echo e($item->tours); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($moveSum); ?></td>
                </tr>
                <tr>
                    <td>Deposits</td>
                    <?php $moveSum = 0; ?>
                    <?php $__currentLoopData = $reportsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $moveSum += $item->deposits; ?>
                        <td><?php echo e($item->deposits); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($moveSum); ?></td>
                </tr>
                <tr>
                    <td>Inquiries to Tour</td>
                    <?php $moveSum = 0; ?>
                    <?php $__currentLoopData = $reportsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->tours == 0): ?>
                            <td>0 %</td>
                        <?php else: ?>
                            <?php $moveSum += $item->deposits / $item->tours; ?>
                            <td><?php echo e($item->deposits / $item->tours); ?> %</td>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($moveSum); ?></td>
                </tr>
                <tr>
                    <td>Tours to Deposits</td>
                    <?php $moveSum = 0; ?>
                    <?php $__currentLoopData = $reportsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->tours == 0): ?>
                            <td>0 %</td>
                        <?php else: ?>
                            <?php $moveSum += $item->deposits / $item->tours; ?>
                            <td><?php echo e($item->deposits / $item->tours); ?> %</td>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($moveSum); ?></td>
                </tr>
            </tbody>
        </table>

        <table class="table table-borderless viewtable table-sm">
            <tbody>
                <tr class="titledate">
                    <th class="MainTitletwo" rowspan="<?php echo e(count($reportsData) + 10); ?>">Move In/Out</th>
                    <th></th>
                    <?php $__currentLoopData = $reportsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th><?php echo e(json_decode($Communities->where(['id' => $item->community_id])->get())[0]->name); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <th>Total</th>
                </tr>
                <tr>
                    <td>WTD Move-Ins</td>
                    <?php $moveSum = 0; ?>
                    <?php $__currentLoopData = $reportsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $moveSum += $item->wtd_movein; ?>
                        <td><?php echo e($item->wtd_movein); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($moveSum); ?></td>
                </tr>
                <tr>
                    <td>WTD Move-Outs</td>
                    <?php $moveSum = 0; ?>
                    <?php $__currentLoopData = $reportsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $moveSum += $item->wtd_moveout; ?>
                        <td><?php echo e($item->wtd_moveout); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($moveSum); ?></td>
                </tr>
                <tr>
                    <td>WTD Net Residents</td>
                    <?php $moveSum = 0; ?>
                    <?php $__currentLoopData = $reportsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $moveSum += $item->wtd_movein - $item->wtd_moveout; ?>
                        <td><?php echo e($item->wtd_movein - $item->wtd_moveout); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($moveSum); ?></td>
                </tr>
                <tr>
                    <td>YTD Move-Ins</td>
                    <?php $moveSum = 0; ?>
                    <?php $__currentLoopData = $reportsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $moveSum += $item->ytd_movein; ?>
                        <td><?php echo e($item->ytd_movein); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($moveSum); ?></td>
                </tr>
                <tr>
                    <td>YTD Move-Outs</td>
                    <?php $moveSum = 0; ?>
                    <?php $__currentLoopData = $reportsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $moveSum += $item->ytd_moveout; ?>
                        <td><?php echo e($item->ytd_moveout); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($moveSum); ?></td>
                </tr>
                <tr>
                    <td>YTD Net Residents</td>
                    <?php $moveSum = 0; ?>
                    <?php $__currentLoopData = $reportsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $moveSum += $item->ytd_movein - $item->ytd_moveout; ?>
                        <td><?php echo e($item->ytd_movein - $item->ytd_moveout); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($moveSum); ?></td>
                </tr>
            </tbody>
        </table>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.container', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/ssd5/289/14284289/public_html/resources/views/ViewCreports.blade.php ENDPATH**/ ?>