<div class="footer bg-white py-4 d-flex flex-lg-column " id="kt_footer">
	<!--begin::Container-->
	OCCUPANCY TRACKER <br>
	Track occupancy at your location
</div>
<?php /**PATH C:\xampp\htdocs\resources\views/layouts/footer.blade.php ENDPATH**/ ?>