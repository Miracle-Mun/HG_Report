<?php $__env->startSection('contents'); ?>

    <?php
        use App\model\reports;
        use App\model\periods;
        use App\model\cencaps;
        use App\model\buildings;
        use App\model\moveouts;
        use App\model\Communities;

        $reports = new reports;
        $periods = new periods;
        $cencaps = new cencaps;
        $buildings = new buildings;
        $moveouts = new moveouts;
        $Communities = new Communities;

        $info = explode(',', Session::get('info'));
        $reportsData = json_decode($reports->where(['community_id' => $info[0], 'period_id' => $info[1]])->get());
        $cencapsData = json_decode($cencaps->where(['report_id' => $reportsData[0]->id])->get());
        $moveoutsData = json_decode($moveouts->where(['report_id' => $reportsData[0]->id])->get());
    ?>

    <div class="row summarycontainer">
        <table class="table table-borderless viewtable">
            <thead>
                <tr>
                    <h3 class="px-2">
                        Report Summary for <?php echo e(json_decode($Communities->where(['id' => $info[0]])->get())[0]->name); ?> from <?php echo e(json_decode($periods->where(['id' => $info[1]])->get())[0]->caption); ?>

                    </h3>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th rowspan="<?php echo e(count($cencapsData) + 2); ?>" class="MainTitle">Census</th>
                    <th></th>
                    <th>Census</th>
                    <th>Capacity</th>
                    <th>%</th>
                </tr>

                <?php $iNum = 0; $cencusSum = 0; $capacitySum = 0;?>
                <?php $__currentLoopData = $cencapsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $cencusSum += $item->census;
                        $capacitySum += $item->capacity;
                    ?>
                    <tr>
                        <td>
                            <?php echo e(json_decode($buildings->where(['id' => $item->building_id])->get())[0]->name); ?>

                        </td>
                        <td><?php echo e($item->census); ?></td>
                        <td><?php echo e($item->capacity); ?></td>
                        <td><?php echo e(number_format(100 * $item->census/$item->capacity, 2, '.', "") . '%'); ?></td>
                    </tr>
                    <?php $iNum++; ?>
                    <?php if( $iNum == count($cencapsData)): ?>
                        <tr>
                            <th>Total</th>
                            <th><?php echo e($cencusSum); ?></th>
                            <th><?php echo e($capacitySum); ?></th>
                            <th><?php echo e(number_format(100 * $cencusSum/$capacitySum, 2, '.', "") . '%'); ?></th>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <?php if(count($moveoutsData) > 0): ?>
            <table class="table table-borderless viewtable">
                <tbody>
                    <tr>
                        <th rowspan="<?php echo e(count($moveoutsData) + 2); ?>" class="MainTitle">Move-Outs</th>
                        <th>Type</th>
                        <th>Count</th>
                    </tr>
                    <?php $iNum = 0; $numSum = 0;?>
                    <?php $__currentLoopData = $moveoutsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->description); ?></td>
                            <td><?php echo e($item->number); ?></td>
                        </tr>
                        <?php $iNum++; $numSum += $item->number; ?>
                        <?php if( $iNum == count($moveoutsData)): ?>
                            <tr>
                                <th>Total</th>
                                <th><?php echo e($numSum); ?></th>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
        <table class="table table-borderless viewtable">
            <tbody>
                <tr>
                    <th rowspan="6" class="MainTitle">Statistics</th>
                    <td>Unqualified</td>
                    <td><?php echo e($reportsData[0]->unqualified); ?></td>
                </tr>
                <tr>
                    <td>Tours</td>
                    <td><?php echo e($reportsData[0]->tours); ?></td>
                </tr>
                <tr>
                    <td>Deposits</td>
                    <td><?php echo e($reportsData[0]->deposits); ?></td>
                </tr>
                <tr>
                    <td>Inquiries to Tours</td>
                    <td><?php echo e($reportsData[0]->unqualified); ?> %</td>
                </tr>
                <tr>
                    <td>Tours to Deposits</td>
                    <?php if($reportsData[0]->tours == 0): ?>
                        <td>0 %</td>
                    <?php else: ?>
                        <td><?php echo e($reportsData[0]->deposits / $reportsData[0]->tours); ?> %</td>
                    <?php endif; ?>
                </tr>
            </tbody>
        </table>
        <table class="table table-borderless viewtable">
            <tbody>
                <tr>
                    <th rowspan="6" class="MainTitle">Move In/Out</th>
                    <td>WTD Move-Ins</td>
                    <td><?php echo e($reportsData[0]->wtd_movein); ?></td>
                </tr>
                <tr>
                    <td>WTD Move-Outs</td>
                    <td><?php echo e($reportsData[0]->wtd_moveout); ?></td>
                </tr>
                <tr>
                    <td>WTD Net Residents</td>
                    <td><?php echo e($reportsData[0]->wtd_movein - $reportsData[0]->wtd_moveout); ?></td>
                </tr>
                <tr>
                    <td>YTD Move-Ins</td>
                    <td><?php echo e($reportsData[0]->ytd_movein); ?></td>
                </tr>
                <tr>
                    <td>YTD Move-Outs</td>
                    <td><?php echo e($reportsData[0]->ytd_moveout); ?></td>
                </tr>
                <tr>
                    <td>YTD Net Residents</td>
                    <td><?php echo e($reportsData[0]->ytd_movein - $reportsData[0]->ytd_moveout); ?></td>
                </tr>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.container', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /storage/ssd5/289/14284289/public_html/laravel_task/resources/views/ViewReports.blade.php ENDPATH**/ ?>